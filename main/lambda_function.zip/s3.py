import boto3
from botocore.exceptions import ClientError
import re
import os
import uuid
from dotenv import load_dotenv
import logging
import json
#from .lambda_handler import generate_presigned_url

load_dotenv()

AWS_REGION = "us-east-1"
AWS_BUCKET_NAME = "staff-task-documents"

LAMBDA_FUNCTION_NAME = 'image-resize-function'

AWS_IAM_ROLE_ARN = os.getenv('AWS_IAM_ROLE_ARN')

# Create an S3 client
s3_client = boto3.client("s3", region_name=AWS_REGION)
lambda_client = boto3.client('lambda', region_name='us-east-1')


def is_valid_bucket_name(bucket_name):
    """Validates the S3 bucket name according to AWS rules."""
    if not (3 <= len(bucket_name) <= 63):
        return False
    if not re.match(r'^[a-z0-9.-]+$', bucket_name):
        return False
    if bucket_name.startswith(("-", ".")) or bucket_name.endswith(("-", ".")):
        return False
    if '..' in bucket_name:
        return False
    return True


def create_bucket(bucket_name=AWS_BUCKET_NAME):
    """Creates an S3 bucket if it doesn't already exist."""
    if not is_valid_bucket_name(bucket_name):
        print(f"Invalid bucket name: '{bucket_name}'")
        raise ValueError(f"Invalid bucket name: '{bucket_name}'")

    try:
        # Check if the bucket exists
        s3_client.head_bucket(Bucket=bucket_name)
        print(f"Bucket '{bucket_name}' already exists.")
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            try:
                if AWS_REGION == "us-east-1":
                    s3_client.create_bucket(Bucket=bucket_name)
                else:
                    s3_client.create_bucket(
                        Bucket=bucket_name,
                        CreateBucketConfiguration={"LocationConstraint": AWS_REGION},
                    )
                print(f"Bucket '{bucket_name}' created successfully.")
            except ClientError as ce:
                print(f"Error creating bucket: {ce}")
                raise
        else:
            print(f"Error checking bucket: {e}")
            raise

def upload_file_to_s3(file, key, bucket_name=AWS_BUCKET_NAME):
    """Uploads a file to S3 and triggers Lambda for resizing."""
    try:
        # Upload the file to S3
        s3_client.upload_fileobj(file, bucket_name, key)
        print(f"File uploaded successfully to {key}.")

        # Optionally, you can log or notify the user that the file was uploaded
    except ClientError as e:
        print(f"Error uploading file to S3: {e}")
        raise

def trigger_lambda_image_processing(original_key):
    """Trigger Lambda to process the image and return the processed image key."""
    lambda_client = boto3.client('lambda')
    
     # Prepare the payload for the Lambda invocation
    payload = {
        "Records": [
            {
                "s3": {
                    "bucket": {
                        "name": AWS_BUCKET_NAME
                    },
                    "object": {
                        "key": original_key
                    }
                }
            }
        ]
    }
    try:
        # Log the request to Lambda for image processing
        logging.info(f"Triggering Lambda for image processing with original key: {original_key}")
        
        # Call the Lambda function with the payload
        response = lambda_client.invoke(
            FunctionName=LAMBDA_FUNCTION_NAME,  # Replace with your Lambda function name
            InvocationType='RequestResponse',  # Synchronous invocation
            Payload=json.dumps(payload)  # The payload data for the Lambda function
        )
        
        # Check the Lambda response status
        status_code = response['StatusCode']
        if status_code == 200:
            logging.info("Lambda invoked successfully.")
        else:
            logging.warning(f"Lambda invocation failed with status code: {status_code}")
        
        # Read the response payload
        response_payload = json.loads(response['Payload'].read().decode('utf-8'))
        
        # Log the response payload from Lambda
        logging.info(f"Lambda response: {response_payload}")

        # Retrieve the processed image key from the Lambda response
        processed_key = response_payload.get('processed_key', '')
        if processed_key:
            logging.info(f"Image processing successful. Processed key: {processed_key}")
        else:
            logging.warning("Lambda response did not include a processed key.")
        
        return processed_key

    except ClientError as e:
        logging.error(f"ClientError occurred while invoking Lambda: {e}")
        
    
    except Exception as e:
        logging.error(f"An error occurred while triggering Lambda: {e}")
        

    try:
        response = lambda_client.invoke(
            FunctionName='YourLambdaFunctionName',  # Replace with your Lambda function name
            InvocationType='RequestResponse',  # Synchronous invocation
            Payload=json.dumps(payload)
        )

        response_payload = json.loads(response['Payload'].read().decode())
        if 'processed_key' in response_payload:
            return response_payload['processed_key']  # Return the processed file key

        else:
            print("Error: Lambda did not return a processed_key.")
            return None

    except Exception as e:
        print(f"Error invoking Lambda: {e}")
        return None


def generate_presigned_url( key, expiration=604800):
    """Generate a presigned URL for accessing the processed file."""
    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': AWS_BUCKET_NAME, 'Key': key},
            ExpiresIn=expiration
        )
        return response
    except Exception as e:
        print(f"Error generating presigned URL: {e}")
        return None


#testing in lambda handler
'''def generate_presigned_url(bucket_name, key, expiration=604800):
    """Generate a pre-signed URL to access the file."""
    try:
        response = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': bucket_name, 'Key': key},
            ExpiresIn=expiration  # URL valid for 1 hour
        )
        return response
    except ClientError as e:
        print(f"Error generating pre-signed URL: {e}")
        return None'''
        

        
def create_lambda_function():
    """Creates a Lambda function for notifications."""
    try:
        response = lambda_client.create_function(
            FunctionName=LAMBDA_FUNCTION_NAME,
            Runtime='python3.9',
            Role=AWS_IAM_ROLE_ARN,
            Handler='lambda_handler.handler',
            Code={'ZipFile': open("lambda_function.zip", "rb").read()},
            Timeout=15
        )
        lambda_arn = response['FunctionArn']
        logging.info(f"Lambda function '{LAMBDA_FUNCTION_NAME}' created with ARN: {lambda_arn}")
        return lambda_arn
    except lambda_client.exceptions.ResourceConflictException:
        lambda_arn = lambda_client.get_function(FunctionName=LAMBDA_FUNCTION_NAME)['Configuration']['FunctionArn']
        logging.info(f"Lambda function '{LAMBDA_FUNCTION_NAME}' already exists with ARN: {lambda_arn}")
        return lambda_arn
    except Exception as e:
        logging.error(f"Error creating or fetching Lambda function: {str(e)}")
        return None

def set_s3_trigger(lambda_arn):
    """Sets up an S3 bucket trigger for the given Lambda function ARN."""
    try:
        # Add permission for S3 to invoke the Lambda function
        try:
            lambda_client.add_permission(
                FunctionName=LAMBDA_FUNCTION_NAME,
                StatementId="S3Invoke",
                Action="lambda:InvokeFunction",
                Principal="s3.amazonaws.com",
                SourceArn=f"arn:aws:s3:::{AWS_BUCKET_NAME}",
            )
        except ClientError as e:
            if e.response["Error"]["Code"] != "ResourceConflictException":
                raise e

        # Configure the S3 bucket to trigger the Lambda function on object creation
        s3_client.put_bucket_notification_configuration(
            Bucket=AWS_BUCKET_NAME,
            NotificationConfiguration={
                "LambdaFunctionConfigurations": [
                    {
                        "LambdaFunctionArn": lambda_arn,
                        "Events": ["s3:ObjectCreated:*"],
                    }
                ]
            },
        )
        print(f"Lambda trigger successfully set for bucket '{AWS_BUCKET_NAME}'.")
    except ClientError as e:
        print(f"Error setting Lambda trigger: {e}")
        raise e



# Example Usage
if __name__ == "__main__":
    # Step 1: Create the S3 Bucket (if not already created)
    create_bucket(AWS_BUCKET_NAME)
    

    
    # Step 2: Create the Lambda function and get its ARN
    lambda_arn = create_lambda_function()
    
    # Step 3: Set the S3 bucket trigger for the created Lambda function
    if lambda_arn:
        set_s3_trigger(lambda_arn)
    else:
        print("Failed to create or fetch Lambda function ARN. Exiting...")
    
    # Step 2: Upload a file to the S3 bucket and get its URL
    # Here we assume the employee is uploading a file, so the filename is dynamic.
    # For example, 'uploaded_image.jpg' will be the actual file chosen by the employee.
    '''uploaded_file_path = 'task_images/8/test2.jpg'  # Replace with the actual file path
    original_file_name = os.path.basename(uploaded_file_path)  # Get the original file name from the path

         # Optionally, use UUID to make it unique, but preserve the original file extension
    unique_key = f"task_images/1/{uuid.uuid4()}_{original_file_name}"
    '''

    # Open the file and upload it with the generated unique key
    '''with open(uploaded_file_path, 'rb') as file:
        file_url = upload_file_to_s3(file, unique_key)
        print(f"Access the file via: {file_url}")'''
